int main() {
	while (i == i+1) {
		//loop
	}
	while (i != i) {
		//loop
	}
	while (i == -i) {
		//loop
	}
}