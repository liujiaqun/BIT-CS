int main() {
	printf("iexplore:");
	http://www.baidu.com;
	printf(":maximize");
}