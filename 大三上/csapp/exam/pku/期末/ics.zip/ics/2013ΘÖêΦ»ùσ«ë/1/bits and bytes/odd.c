int odd(int i) {
	if (i % 2 == 1) return true;
	return false;
}