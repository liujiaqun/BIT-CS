int main() {
	long long a = 0x100000000LL;
	int b =        0xcafebabe;
	long long x = a + b;
	printf("%llx\n", x);
}