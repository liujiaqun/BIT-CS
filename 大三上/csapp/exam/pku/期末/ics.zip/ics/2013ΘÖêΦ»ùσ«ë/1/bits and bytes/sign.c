int main() {
	printf("%d\n", (int)(unsigned char)-1);
	printf("%d\n", (int)(char)-1);
}