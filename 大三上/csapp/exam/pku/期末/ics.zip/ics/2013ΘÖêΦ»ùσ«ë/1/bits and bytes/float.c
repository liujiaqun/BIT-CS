int main() {
	int s = 2000000000;
	int cnt = 0;
	for (float f = s; f < s + 50; ++f)
		cnt++;
	printf("%d\n", cnt);
}